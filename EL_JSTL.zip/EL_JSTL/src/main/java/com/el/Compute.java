package com.el;

public class Compute {
	public static int sum(String x, String y) {
		return Integer.parseInt(x) + Integer.parseInt(y);
	}
}
