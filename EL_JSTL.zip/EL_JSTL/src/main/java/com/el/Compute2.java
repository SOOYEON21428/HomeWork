package com.el;

public class Compute2 {
	public static int mul(String x, String y) {
        return Integer.parseInt(x) * Integer.parseInt(y);
    }
}
